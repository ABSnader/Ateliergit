typedef struct absenteisme absenteisme;
struct absenteisme{
char id[20];
int jj;
int mm;
int aa;
int present;
};
float calculer_taux_absenteisme();
