int valeur_max(float tab[],int n);
int annee_seche(int tab_an[],float tab_temp[]);
