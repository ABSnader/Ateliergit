#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include <string.h>
#include <stdlib.h>
#include "support.h"
#include "client.h"



void
on_button_confirmer_ajouter_gestion_client_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
client c;

	GtkWidget *entrynom;
	GtkWidget *entryprenom;
	GtkWidget *entryadresse;
	GtkWidget *entrycin;
	GtkWidget *entrynum_tel;
	GtkWidget *gestion;
	GtkWidget *success;
	GtkWidget *existe;
	GtkWidget *entry_jour_naiss;
	GtkWidget *entry_mois_naiss;
	GtkWidget *entry_annee_naiss;
	GtkWidget *entry_situation_sociale;
	GtkWidget *entry_nationalite;
	GtkWidget *entry_homme;
	GtkWidget *entry_femme;
	int b=1;

	

	entrynom=lookup_widget(objet,"entry_nom_ajouter_gestion_client");
	entryprenom=lookup_widget(objet,"entry_prenom_ajouter_gestion_client");
	entrycin=lookup_widget(objet,"entry_cin_ajouter_gestion_client");
	entryadresse=lookup_widget(objet,"entry_adresse_ajouter_gestion_client");
	entrynum_tel=lookup_widget(objet,"entry_tel_ajouter_gestion_client");
	success=lookup_widget(objet,"label_client_succes_ajouter"); 
	existe=lookup_widget(objet,"label_client_existe_ajouter"); 

	entry_jour_naiss=lookup_widget(objet,"spinbutton_jour_ajouter_gestion_client");
	entry_mois_naiss=lookup_widget(objet,"spinbutton_mois_ajouter_gestion_client");
	entry_annee_naiss=lookup_widget(objet,"spinbutton_annee_ajouter_gestion_client");

	entry_situation_sociale=lookup_widget(objet,"comboboxentry_situation_ajouter_gestion_client");
	entry_nationalite=lookup_widget(objet,"comboboxentry_nationalite_ajouter_gestion_client");

	entry_homme=lookup_widget(objet,"radiobutton_homme_ajouter_gestion_client");
	entry_femme=lookup_widget(objet,"radiobutton_femme_ajouter_gestion_client");

	strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(entrynom) ) );
	strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(entryprenom) ) );
	strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(entrycin) ) );
	strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(entryadresse) ) );
	strcpy(c.num_tel,gtk_entry_get_text(GTK_ENTRY(entrynum_tel) ) );

	c.dt_naiss.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_jour_naiss));
	c.dt_naiss.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_mois_naiss));
	c.dt_naiss.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_annee_naiss));

	strcpy(c.situation_sociale,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_situation_sociale)));
	strcpy(c.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_nationalite)));
	
	
	if(s==1)
	strcpy(c.sexe,"homme");
	else 
	strcpy(c.sexe,"femme");
	
	gtk_widget_hide (success);
	//condition_ajout
	if(strcmp(c.nom,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_nom_ajouter"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_nom_ajouter"));
	}

	if(strcmp(c.prenom,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_prenom_ajouter"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_prenom_ajouter"));
	}

	if(strcmp(c.cin,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_cin_ajouter"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_cin_ajouter"));
	}

	if(strcmp(c.adresse,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_adresse_ajouter"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_adresse_ajout"));
	}

	if(strcmp(c.num_tel,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_tel_ajouter"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_tel_ajouter"));
	}

	if(b==1){
        if(exist_client(c.cin)==1)
        {

		gtk_widget_show (existe);
        }
        else
	{
		gtk_widget_hide (existe);
                ajouter_client(c);
		gtk_widget_show (success);
        }

	
	}

}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *gestion;
	GtkTreeIter iter;
		gchar *NOM;
		gchar *PRENOM;
		gchar *CIN;
		gchar *ADRESSE;
		gchar *NUM_TEL;
		gint  JOUR_NAISS;
		gint  MOIS_NAISS;
		gint  ANNEE_NAISS;
		gchar *SITUATION_SOCIALE;
		gchar *NATIONALITE;
		gchar *SEXE;
		
	client c;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{
	//obtention des valeurs de le ligne selectionne
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&NOM,1,&PRENOM,2,&CIN,3,&ADRESSE,4,&NUM_TEL,5,&JOUR_NAISS,6,&MOIS_NAISS,7,&ANNEE_NAISS,8,&SITUATION_SOCIALE,9,&NATIONALITE,10,&SEXE,-1);
	
	//copie des valeurs  pour le passer a la fonction supprimer  
	strcpy(c.cin,CIN);
	supprimer_client(c.cin);
	afficher_client(treeview,"client.txt"); 
	}

}


void
on_button_modifier_client_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE *f;
	f=fopen("modifier.txt","w");
	GtkWidget* gestion;

	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
        //GtkWidget *label;
	client c;
        gchar* nom;
	gchar* prenom;
	gchar* cin;
	gchar* adresse;
	gchar* num_tel;
	//gchar* type gtk ==> chaine en c car la fonction gtk_tree_model_get naccepte que gchar*
        //label=lookup_widget(gestion,"label23");
        p=lookup_widget(objet,"treeview2");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
        {
		gtk_tree_model_get (model,&iter,0,&nom,1,&prenom,2,&cin,3,&adresse,4,&num_tel,-1);

	        gtk_entry_set_text(GTK_ENTRY(lookup_widget(objet,"entry_nom_modifier_gestion_client")),nom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(objet,"entry_prenom_modifier_gestion_client")),prenom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(objet,"entry_adresse_modifier_gestion_client")),adresse);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(objet,"entry_tel_modifier_gestion_client")),num_tel);
 
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView
	   gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(objet,"notebook3")));
	   fprintf(f,"%s",cin);
	   //supprimer_client(cin);
	   
	
	}// modifier la ligne du fichier
	fclose(f);
}


void
on_button_rechercher_client_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *NOM;
	GtkWidget *gestion;
	GtkWidget *treeview1;
	char nom[100];
	NOM=lookup_widget (objet,"entry_rechercher_client");
	gestion=lookup_widget(objet,"Gestion");
	strcpy(nom, gtk_entry_get_text(GTK_ENTRY(NOM)));
	treeview1=lookup_widget(gestion,"treeview1");
	chercher_client(treeview1,nom);
	
}


void
on_button_acceuil_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *acceuil;
	GtkWidget *gestion;
	GtkWidget *treeview1;
	GtkWidget *treeview2;
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_hide (acceuil);
	gestion=lookup_widget(objet,"Gestion");
	gestion=create_Gestion();
	gtk_widget_show (gestion);
	treeview2=lookup_widget(gestion,"treeview2");
	afficher_client(treeview2,"client.txt");
	treeview1=lookup_widget(gestion,"treeview1");
	afficher_client(treeview1,"client.txt");
}



void
on_button_mise_ajouter_gestion_client_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE *f;
	GtkWidget *entrynom;
	GtkWidget *entryprenom;
	GtkWidget *entryadresse;
	GtkWidget *entrynum_tel;
	GtkWidget *gestion;
	GtkWidget *sortie;
	GtkWidget *entry_jour_naiss;
	GtkWidget *entry_mois_naiss;
	GtkWidget *entry_annee_naiss;
	GtkWidget *entry_situation_sociale;
	GtkWidget *entry_nationalite;
	GtkWidget *entry_homme;
	GtkWidget *entry_femme;
	int b=1;

	f=fopen("modifier.txt","r");
	client c;
	fscanf(f,"%s",c.cin);
	entrynom=lookup_widget(objet,"entry_nom_modifier_gestion_client");
	entryprenom=lookup_widget(objet,"entry_prenom_modifier_gestion_client");
	entryadresse=lookup_widget(objet,"entry_adresse_modifier_gestion_client");
	entrynum_tel=lookup_widget(objet,"entry_tel_modifier_gestion_client");
	sortie=lookup_widget(objet,"label_succes_modifier"); 

	entry_jour_naiss=lookup_widget(objet,"spinbutton_jour_modifier_gestion_client");
	entry_mois_naiss=lookup_widget(objet,"spinbutton_mois_modifier_gestion_client");
	entry_annee_naiss=lookup_widget(objet,"spinbutton_annee_modifier_gestion_client");

	entry_situation_sociale=lookup_widget(objet,"comboboxentry_situation_modifier_gestion_client");
	entry_nationalite=lookup_widget(objet,"comboboxentry_nationalite_modifier_gestion_client");

	entry_homme=lookup_widget(objet,"radiobutton_homme_modifier_gestion_client");
	entry_femme=lookup_widget(objet,"radiobutton_femme_modifier_gestion_client");

	strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(entrynom) ) );
	strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(entryprenom) ) );
	strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(entryadresse) ) );
	strcpy(c.num_tel,gtk_entry_get_text(GTK_ENTRY(entrynum_tel) ) );

	c.dt_naiss.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_jour_naiss));
	c.dt_naiss.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_mois_naiss));
	c.dt_naiss.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_annee_naiss));

	strcpy(c.situation_sociale,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_situation_sociale)));
	strcpy(c.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_nationalite)));

	if(s==1)
	strcpy(c.sexe,"homme");
	else 
	strcpy(c.sexe,"femme");
	
	//ajouter_client(c);
	//condition_ajout

	if(strcmp(c.nom,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_nom_modifier"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_nom_modifier"));
	}

	if(strcmp(c.prenom,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_prenom_modifier"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_prenom_modifier"));
	}


	if(strcmp(c.adresse,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_adresse_modifier"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_adresse_modifier"));
	}

	if(strcmp(c.num_tel,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_num_tel_modifier"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_num_tel_modifier"));
	}
        if(b==1) {
		supprimer_client(c.cin);
	
                ajouter_client(c);


						  gtk_widget_show (sortie);
        }

}


void
on_button_refresh_client_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *gestion;
	GtkWidget *treeview2;
	GtkWidget *treeview1;
	gestion=lookup_widget(objet,"Gestion");
	treeview2=lookup_widget(gestion,"treeview2");
	afficher_client(treeview2,"client.txt"); 
	treeview2=lookup_widget(gestion,"treeview1");
	afficher_client(treeview1,"client.txt");
}


void
on_radiobutton_homme_ajouter_gestion_client_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton));
	s=1;
}


void
on_radiobutton_femme_ajouter_gestion_client_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton));
	s=2;
}


void
on_radiobutton_homme_modifier_gestion_client_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton));
	s=1;
}


void
on_radiobutton_femme_modifier_gestion_client_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton));
	s=2;
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
	GtkWidget *gestion;
	GtkTreeIter iter;
		gchar *NOM;
		gchar *PRENOM;
		gchar *CIN;
		gchar *ADRESSE;
		gchar *NUM_TEL;
		gint  JOUR_NAISS;
		gint  MOIS_NAISS;
		gint  ANNEE_NAISS;
		gchar *SITUATION_SOCIALE;
		gchar *NATIONALITE;
		gchar *SEXE;
		
	client c;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{
	//obtention des valeurs de le ligne selectionne
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&NOM,1,&PRENOM,2,&CIN,3,&ADRESSE,4,&NUM_TEL,5,&JOUR_NAISS,6,&MOIS_NAISS,7,&ANNEE_NAISS,8,&SITUATION_SOCIALE,9,&NATIONALITE,10,&SEXE,-1);
	
	//copie des valeurs  pour le passer a la fonction supprimer  
	strcpy(c.nom,NOM);
	afficher_client(treeview,"client.txt"); 
}
}

