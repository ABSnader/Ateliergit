#include <gtk/gtk.h>


void
on_button_confirmer_ajouter_gestion_client_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_modifier_client_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rechercher_client_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_acceuil_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mise_ajouter_gestion_client_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_refresh_client_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_homme_ajouter_gestion_client_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_ajouter_gestion_client_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_homme_modifier_gestion_client_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_modifier_gestion_client_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
