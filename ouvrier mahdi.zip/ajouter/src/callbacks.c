#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include <string.h>
#include <stdlib.h>
#include "support.h"
#include "ouvrier.h"


void
on_button_acceuil_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)

{
	GtkWidget *acceuil;
	GtkWidget *gestion;
	GtkWidget *treeview1;
	GtkWidget *treeview2;
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_hide (acceuil);
	gestion=lookup_widget(objet,"gestion");
	gestion=create_gestion();
	gtk_widget_show (gestion);
	treeview1=lookup_widget(gestion,"treeview1");
	afficher_ouvrier(treeview1,"ouvrier.txt");
	treeview2=lookup_widget(gestion,"treeview2");
	afficher_ouvrier(treeview2,"ouvrier.txt");
}


void
on_button_confirmer_ajouter_ouvrier_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	ouvrier ov;

	GtkWidget *entrynom;
	GtkWidget *entryprenom;
	GtkWidget *entryadresse;
	GtkWidget *entrycin;
	GtkWidget *entrysalaire_actuel;
	GtkWidget *entrynum_tel;
	GtkWidget *gestion;
	GtkWidget *success;
	GtkWidget *existe;
	GtkWidget *entry_jour_emb;
	GtkWidget *entry_mois_emb;
	GtkWidget *entry_annee_emb;
	GtkWidget *entry_jour_naiss;
	GtkWidget *entry_mois_naiss;
	GtkWidget *entry_annee_naiss;
	GtkWidget *entry_situation_sociale;
	GtkWidget *entry_nationalite;
	GtkWidget *entry_homme;
	GtkWidget *entry_femme;
	int b=1;

	gestion=create_gestion();

	entrynom=lookup_widget(objet,"entry_nom_ajouter_ouvrier");
	entryprenom=lookup_widget(objet,"entry_prenom_ajouter_ouvrier");
	entrycin=lookup_widget(objet,"entry_cin_ajouter_ouvrier");
	entryadresse=lookup_widget(objet,"entry_adresse_ajouter_ouvrier");
	entrysalaire_actuel=lookup_widget(objet,"entry_salaire_actuel_ajouter_ouvrier");
	entrynum_tel=lookup_widget(objet,"entry_n_tel_ajouter_ouvrier");
	success=lookup_widget(objet,"label_ouvrier_succes_ajout"); 
	existe=lookup_widget(objet,"label_ouvrier_existe_ajout"); 

	entry_jour_emb=lookup_widget(objet,"spinbutton_jour_date_embauche_ajouter_ouvrier");
	entry_mois_emb=lookup_widget(objet,"spinbutton_mois_date_embauche_ajouter_ouvrier");
	entry_annee_emb=lookup_widget(objet,"spinbutton_annee_date_embauche_ajouter_ouvrier");

	entry_jour_naiss=lookup_widget(objet,"spinbutton_jour_date_naissance_ajouter_ouvrier");
	entry_mois_naiss=lookup_widget(objet,"spinbutton_mois_date_naissance_ajouter_ouvrier");
	entry_annee_naiss=lookup_widget(objet,"spinbutton_annee_date_naissance_ajouter_ouvrier");

	entry_situation_sociale=lookup_widget(objet,"comboboxentry_situation_sociale_ajouter_ouvrier");
	entry_nationalite=lookup_widget(objet,"comboboxentry_nationalite_ajouter_ouvrier");

	entry_homme=lookup_widget(objet,"radiobutton_homme_sexe_ajouter_ouvrier");
	entry_femme=lookup_widget(objet,"radiobutton_femme_sexe_ajouter_ouvrier");

	strcpy(ov.nom,gtk_entry_get_text(GTK_ENTRY(entrynom) ) );
	strcpy(ov.prenom,gtk_entry_get_text(GTK_ENTRY(entryprenom) ) );
	strcpy(ov.cin,gtk_entry_get_text(GTK_ENTRY(entrycin) ) );
	strcpy(ov.adresse,gtk_entry_get_text(GTK_ENTRY(entryadresse) ) );
	strcpy(ov.salaire_actuel,gtk_entry_get_text(GTK_ENTRY(entrysalaire_actuel) ) );
	strcpy(ov.num_tel,gtk_entry_get_text(GTK_ENTRY(entrynum_tel) ) );

	ov.dt_emb.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_jour_emb));
	ov.dt_emb.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_mois_emb));
	ov.dt_emb.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_annee_emb));

	ov.dt_naiss.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_jour_naiss));
	ov.dt_naiss.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_mois_naiss));
	ov.dt_naiss.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_annee_naiss));

	strcpy(ov.situation_sociale,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_situation_sociale)));
	strcpy(ov.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_nationalite)));
	
	
	if(s==1)
	strcpy(ov.sexe,"homme");
	else 
	strcpy(ov.sexe,"femme");
	
	gtk_widget_hide (success);
	//condition_ajout
	if(strcmp(ov.nom,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_nom_ajout"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_nom_ajout"));
	}

	if(strcmp(ov.prenom,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_prenom_ajout"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_prenom_ajout"));
	}

	if(strcmp(ov.cin,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_cin_ajout"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_cin_ajout"));
	}

	if(strcmp(ov.adresse,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_cin_ajout"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_adresse_ajout"));
	}

	if(strcmp(ov.salaire_actuel,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_salaire_actuel_ajout"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_salaire_actuel_ajout"));
	}

	if(strcmp(ov.num_tel,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_num_tel_ajout"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_num_tel_ajout"));
	}

	if(b==1){

        if(exist_ouvier(ov.cin)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_ouvrier(ov);

						  gtk_widget_show (success);
        }

	
	}

}


void
on_radiobutton_homme_sexe_ajouter_ouvrier_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton));
	s=1;
}


void
on_radiobutton_femme_sexe_ajouter_ouvrier_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton));
	s=2;
}


void
on_button_modifier_ouvrier_clicked     (GtkWidget        *objet,
                                        gpointer         user_data)
{
	FILE *f;
	f=fopen("modifier.txt","w");
	GtkWidget* gestion;

	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
	ouvrier ov;
        gchar* nom;
	gchar* prenom;
	gchar* cin;
	gchar* adresse;
	gchar* salaire_actuel;
	gchar* num_tel;
	gchar* jour_emb;
	gint* mois_emb;
	gint* annee_emb;
        p=lookup_widget(objet,"treeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
        {  gtk_tree_model_get (model,&iter,0,&nom,1,&prenom,2,&cin,3,&adresse,4,&salaire_actuel,5,&num_tel,-1);

	        gtk_entry_set_text(GTK_ENTRY(lookup_widget(objet,"entry_nom_modifier_ouvrier")),nom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(objet,"entry_prenom_modifier_ouvrier")),prenom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(objet,"entry_adresse_modifier_ouvrier")),adresse);
          	gtk_entry_set_text(GTK_ENTRY(lookup_widget(objet,"entry_salaire_actuel_modifier_ouvrier")),salaire_actuel);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(objet,"entry_n_tel_modifier_ouvrier")),num_tel);
 
		

           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView
	   gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(objet,"notebook2")));
	   fprintf(f,"%s",cin);
	   supprimer_ouvrier(cin);
	   
	
	}// modifier la ligne du fichier
	fclose(f);



}




void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkWidget *gestion;
	GtkTreeIter iter;
		gchar *NOM;
		gchar *PRENOM;
		gchar *CIN;
		gchar *ADRESSE;
		gchar *SALAIRE_ACTUEL;
		gchar *NUM_TEL;
		gint  JOUR_EMB;
		gint  MOIS_EMB;
		gint  ANNEE_EMB;
		gint  JOUR_NAISS;
		gint  MOIS_NAISS;
		gint  ANNEE_NAISS;
		gchar *SITUATION_SOCIALE;
		gchar *NATIONALITE;
		gchar *SEXE;
		
	ouvrier ov;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{
	//obtention des valeurs de le ligne selectionne
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&NOM,1,&PRENOM,2,&CIN,3,&ADRESSE,4,&SALAIRE_ACTUEL,5,&NUM_TEL,6,&JOUR_EMB,7,&MOIS_EMB,8,&ANNEE_EMB,9,&JOUR_NAISS,10,&MOIS_NAISS,11,&ANNEE_NAISS,12,&SITUATION_SOCIALE,13,&NATIONALITE,14,&SEXE,-1);
	
	//copie des valeurs  pour le passer a la fonction supprimer  
	strcpy(ov.cin,CIN);
	supprimer_ouvrier(ov.cin);
	afficher_ouvrier(treeview,"ouvrier.txt"); 
}

}


void
on_radiobutton_homme_sexe_modifier_ouvrier_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton));
	s=1;
}


void
on_radiobutton_femme_sexe_modifier_ouvrier_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton));
	s=2;
}


void
on_button_mise_a_jour_ouvrier_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	FILE *f;
	GtkWidget *entrynom;
	GtkWidget *entryprenom;
	GtkWidget *entryadresse;
	GtkWidget *entrysalaire_actuel;
	GtkWidget *entrynum_tel;
	GtkWidget *gestion;
	GtkWidget *sortie;
	GtkWidget *entry_jour_emb;
	GtkWidget *entry_mois_emb;
	GtkWidget *entry_annee_emb;
	GtkWidget *entry_jour_naiss;
	GtkWidget *entry_mois_naiss;
	GtkWidget *entry_annee_naiss;
	GtkWidget *entry_situation_sociale;
	GtkWidget *entry_nationalite;
	GtkWidget *entry_homme;
	GtkWidget *entry_femme;
	int b=1;

	f=fopen("modifier.txt","r");
	ouvrier ov;
	fscanf(f,"%s",ov.cin);
	entrynom=lookup_widget(objet,"entry_nom_modifier_ouvrier");
	entryprenom=lookup_widget(objet,"entry_prenom_modifier_ouvrier");
	entryadresse=lookup_widget(objet,"entry_adresse_modifier_ouvrier");
	entrysalaire_actuel=lookup_widget(objet,"entry_salaire_actuel_modifier_ouvrier");
	entrynum_tel=lookup_widget(objet,"entry_n_tel_modifier_ouvrier");
	sortie=lookup_widget(objet,"label_succes_modifier"); 

	entry_jour_emb=lookup_widget(objet,"spinbutton_jour_date_embauche_modifier_ouvrier");
	entry_mois_emb=lookup_widget(objet,"spinbutton_mois_date_embauche_modifier_ouvrier");
	entry_annee_emb=lookup_widget(objet,"spinbutton_annee_date_embauche_modifier_ouvrier");

	entry_jour_naiss=lookup_widget(objet,"spinbutton_jour_date_naissance_modifier_ouvrier");
	entry_mois_naiss=lookup_widget(objet,"spinbutton_mois_date_naissance_modifier_ouvrier");
	entry_annee_naiss=lookup_widget(objet,"spinbutton_annee_date_naissance_modifier_ouvrier");

	entry_situation_sociale=lookup_widget(objet,"comboboxentry_situation_sociale_modifier_ouvrier");
	entry_nationalite=lookup_widget(objet,"comboboxentry_nationalite_modifier_ouvrier");

	entry_homme=lookup_widget(objet,"radiobutton_homme_sexe_modifier_ouvrier");
	entry_femme=lookup_widget(objet,"radiobutton_femme_sexe_modifier_ouvrier");

	strcpy(ov.nom,gtk_entry_get_text(GTK_ENTRY(entrynom) ) );
	strcpy(ov.prenom,gtk_entry_get_text(GTK_ENTRY(entryprenom) ) );
	strcpy(ov.adresse,gtk_entry_get_text(GTK_ENTRY(entryadresse) ) );
	strcpy(ov.salaire_actuel,gtk_entry_get_text(GTK_ENTRY(entrysalaire_actuel) ) );
	strcpy(ov.num_tel,gtk_entry_get_text(GTK_ENTRY(entrynum_tel) ) );

	ov.dt_emb.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_jour_emb));
	ov.dt_emb.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_mois_emb));
	ov.dt_emb.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_annee_emb));

	ov.dt_naiss.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_jour_naiss));
	ov.dt_naiss.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_mois_naiss));
	ov.dt_naiss.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entry_annee_naiss));

	strcpy(ov.situation_sociale,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_situation_sociale)));
	strcpy(ov.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entry_nationalite)));

	if(s==1)
	strcpy(ov.sexe,"homme");
	else 
	strcpy(ov.sexe,"femme");
	
	ajouter_ouvrier(ov);
	//condition_ajout

	if(strcmp(ov.nom,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_nom_modifier"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_nom_modifier"));
	}

	if(strcmp(ov.prenom,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_prenom_modifier"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_prenom_modifier"));
	}


	if(strcmp(ov.adresse,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_adresse_modifier"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_adresse_modifier"));
	}

	if(strcmp(ov.salaire_actuel,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_salaire_actuel_modifier"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_salaire_actuel_modifier"));
	}

	if(strcmp(ov.num_tel,"")==0){
			  gtk_widget_show (lookup_widget(objet,"label_echec_num_tel_modifier"));
	b=0;
	}
	else {
			  gtk_widget_hide(lookup_widget(objet,"label_echec_num_tel_modifier"));
	}
        if(b==1) {
	
                ajouter_ouvrier(ov);

						  gtk_widget_show (sortie);
        }


}




void
on_buttonrefresh_clicked               (GtkWidget        *objet,
                                        gpointer         user_data)
{
	GtkWidget *gestion;
	GtkWidget *treeview1;
	gestion=lookup_widget(objet,"gestion");
	treeview1=lookup_widget(gestion,"treeview1");
	afficher_ouvrier(treeview1,"ouvrier.txt"); 	
}


void
on_button_rechercher_ouvrier_clicked   (GtkWidget        *objet,
                                        gpointer         user_data)
{
	GtkWidget *NOM;
	GtkWidget *gestion;
	GtkWidget *treeview2;
	char nom[100];
	NOM=lookup_widget (objet,"entry_rechercher_ouvrier");
	gestion=lookup_widget(objet,"gestion");
	strcpy(nom, gtk_entry_get_text(GTK_ENTRY(NOM)));
	treeview2=lookup_widget(gestion,"treeview2");
	chercher_ouvrier(treeview2,nom);
	
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkWidget *treeview2;
	GtkWidget *gestion;
	GtkTreeIter iter;
		gchar *NOM;
		gchar *PRENOM;
		gchar *CIN;
		gchar *ADRESSE;
		gchar *SALAIRE_ACTUEL;
		gchar *NUM_TEL;
		gint  JOUR_EMB;
		gint  MOIS_EMB;
		gint  ANNEE_EMB;
		gint  JOUR_NAISS;
		gint  MOIS_NAISS;
		gint  ANNEE_NAISS;
		gchar *SITUATION_SOCIALE;
		gchar *NATIONALITE;
		gchar *SEXE;
		
	ouvrier ov;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path))
	{
	//obtention des valeurs de le ligne selectionne
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&NOM,1,&PRENOM,2,&CIN,3,&ADRESSE,4,&SALAIRE_ACTUEL,5,&NUM_TEL,6,&JOUR_EMB,7,&MOIS_EMB,8,&ANNEE_EMB,9,&JOUR_NAISS,10,&MOIS_NAISS,11,&ANNEE_NAISS,12,&SITUATION_SOCIALE,13,&NATIONALITE,14,&SEXE,-1);
	
	//copie des valeurs  pour le passer a la fonction supprimer  
	strcpy(ov.nom,NOM);
	afficher_ouvrier(treeview,"ouvrier.txt"); 
}

}



void
on_button_retour_clicked               (GtkWidget        *objet,
                                        gpointer         user_data)
{

	GtkWidget *acceuil;
	GtkWidget *gestion;
	acceuil=lookup_widget(objet,"acceuil");
	gestion=lookup_widget(objet,"gestion");
	acceuil=create_acceuil();
	gtk_widget_hide (gestion);
	gtk_widget_show (acceuil);
}

