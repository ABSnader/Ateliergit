#include <gtk/gtk.h>


void
on_button_acceuil_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_confirmer_ajouter_ouvrier_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_homme_sexe_ajouter_ouvrier_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_sexe_ajouter_ouvrier_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void 
on_button_modifier_ouvrier_clicked     (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton_homme_sexe_modifier_ouvrier_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_sexe_modifier_ouvrier_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_mise_a_jour_ouvrier_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonrefresh_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rechercher_ouvrier_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_retour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_meilleur_ouvrier_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_submit_meilleur_ouvrier_clicked
                                        (GtkWidget        *objet,
                                        gpointer         user_data);
